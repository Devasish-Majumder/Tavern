# Tavern-Management-System

This is a restaurant management software which I developed for one of the assignment in Programming 1 course in University.

## Features !

- Intuitive user interface
- Desktop application
- File Based Data storage
- Easy to modify design
- Multiple modules
  - Basic Authentication
  - Item Management
  - Order Management
  - Labour Management
  - Billing Management

## How to edit this project ?

Best way to open and edit the project is to use Netbeans IDE. It allows very easy way to modify the design (Drag and Drop)

## Authentication

There is no standard authentication has been added yet. Currently, it is hardcoded.

```
Username : Paparazi
Password : Paparazi
```
